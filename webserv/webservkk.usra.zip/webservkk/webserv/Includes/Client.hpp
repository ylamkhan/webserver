#ifndef CLIENT_HPP
#define CLIENT_HPP

#include "../Includes/httpRequest.hpp"

#include <string>
#include <map>
#include <iostream>
#include <vector>
#include <fstream>

static std::string name_file = "out";
static bool flag= false;
class Socket;

class Client {
    private:
        int sockfd;
        std::ofstream file;
        //Request request;
        int flag;
        int servfd;
        bool flagf;
        std::string name_path;
        std::string requesta;

// request 
        std::string method;
        std::string path;
        std::string httpVersion;
        std::vector<std::pair<std::string, std::string> > headers;
        std::string body;
        std::string requestStr;
        bool headerSet;

    public:
        Client();
        ~Client();
        Client &operator=(Client const &other);
        Client(Client const &other);
        int getSocket() const;
        void setFlg(bool flag);
        bool getFlg();
        // Request getRequest() const;
        void setFd(int fd);
        //void setRequest(Request &r);
        void setServFd(int fd);
        void open_file();
        std::string get_file_name() const ;
        void parseRequest(const std::string& httpRequest);
        void set_request_client(std::string requ);

        
        //request 
        std::string getMethod() const;
        std::string getPath() const;
        std::string getHTTPVersion() const;
        std::vector<std::pair<std::string, std::string> > getHeaders() const;
        std::string getBody() const;
       std::string getReqStr() const;
        void    setReqStr(std::string s);
        void    handl_methodes();
};

#endif

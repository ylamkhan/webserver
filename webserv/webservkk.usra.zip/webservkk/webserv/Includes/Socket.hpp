#ifndef SOCKET_HPP
#define SOCKET_HPP

#include <sys/epoll.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdexcept>
#include <vector>
#include <map>
#include "../Includes/Server_Data.hpp"
#include "../Includes/Client.hpp"
#include "../Includes/httpRequest.hpp"
#include "../Includes/httpResponse.hpp"

#define  maxEvents  10
class Server;
class Client;

class Socket {
    private:
        //std::vector<Server> &servers;
        epoll_event events[maxEvents];
        int epollfd;
        // Client client;
        epoll_event event;
        std::vector<int> serverSockets;
        std::map<int, Client> mapClient;
        //std::pair<int, int> ClientServer;

    public:
        Socket &operator=(Socket const &other);
        Socket(Socket const &other);
        Socket(const std::vector<Server>& servers);
        ~Socket();
        void handleConnections();
        //void handleRequest(Client& client, const Request& request);
        //Response processGetRequest(const Request& request);
        //Response processPostRequest(const Request& request);
        //Response processDeleteRequest(const Request& request);
        void setMapClient(int fd, Client &c);
        std::map<int, Client> getMapClient() const;
};

#endif

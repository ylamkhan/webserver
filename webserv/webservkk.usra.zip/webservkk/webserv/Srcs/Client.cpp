#include "../Includes/Client.hpp"
#include <unistd.h>
#include <fstream>

Client::Client()  {
    flag = false;
  
    open_file();
}

Client::~Client() {
    // close(sockfd);
}


Client &Client::operator=(Client const &other)
{
        // if(file)
        sockfd = other.sockfd;
        //Request request = other.
        flag = other.flag;
        servfd = other.servfd;
        flagf = other.flagf;
        name_path = other.name_path;
        requesta = other.requesta;

// request 
        method = other.method;
        path = other.path;
        httpVersion = other.httpVersion;
        headers = other.headers;
        body = other.body;
        requestStr = other.requestStr;
        headerSet = other.headerSet;
        return *this;
}
Client::Client(Client const &other)
{
    *this = other;
}
int Client::getSocket() const {
    return sockfd;
}

std::string Client::get_file_name() const 
{
    return name_path;
}

void Client::set_request_client(std::string requ)
{
    parseRequest(requ);
}



void    Client::parseRequest(const std::string& httpRequest)
{
    if (!headerSet)
        setReqStr(httpRequest);
    if (!headerSet && requestStr.find("\r\n\r\n", 0) != std::string::npos)
    {
        size_t pos = 0;
        size_t end = 0;
        end = requestStr.find(' ');
        method = requestStr.substr(pos, end - pos);
        pos = end + 1;
        end = requestStr.find(' ', pos);
        path = requestStr.substr(pos, end - pos);
        pos = end + 1;
        end = requestStr.find("\r\n", pos);
        httpVersion = requestStr.substr(pos, end - pos);
        pos = end + 2;
        while ((end = requestStr.find("\r\n", pos)) != std::string::npos)
        {
            std::string line = requestStr.substr(pos, end - pos);
            if (line.empty())
                break;
            size_t separatorPos = line.find(':');
            if (separatorPos != std::string::npos) {
                std::string headerName = line.substr(0, separatorPos);
                std::string headerValue = line.substr(separatorPos + 2);
                headers.push_back(std::make_pair(headerName, headerValue));
            }
            pos = end + 2;
        }
        body = requestStr.substr(pos);
        headerSet = true;
    }
    else /*if (headerSet)*/{
        body = httpRequest;
    }
    handl_methodes();
}
void   Client::handl_methodes()
{
    
    // if(method == "GET")
    // {
        
    // }
    //----clinet------
    // if (flagopen)
    // {
    //     openFIle(path);
    // }
    // --------------------------
    // rondom name /upload/ + name + mp4 
    //

    //  if(method == "POST")
    // {
        //std::cout << body << "\n";
        //if(!body.empty())
        std::cout << body << "\n";
        file.write(body.c_str(), body.size());
        // std::cout << "hello \n";
        
       
    // }
    // else if (method == "DELETE")
    // {
        
    // }
    // else
    // {
    //     std::cerr<<"Error: not found method\n";
    //     return ;
    // }
}



void Client::open_file()
{
    std::string name;
    if (!flagf)
    {
        name_file += "t";
        name = "/nfs/homes/ylamkhan/Downloads/webserv/webservkk/webserv/Srcs/upload" + name_file + ".txt";  
        file.open(name.c_str(), std::ios::app);
        flagf = true;
    }
}

// Request Client::getRequest() const {
   
//     return request;
// }

void Client::setFd(int fd) {
    sockfd = fd;
}

void Client::setFlg(bool flag){
    this->flag = flag;
}
bool Client::getFlg(){
    return flag;
}

// void Client::setRequest(Request &r) {
//     request = r;
// }

void Client::setServFd(int fd) {
    servfd = fd;
}

// request 

std::string Client::getMethod() const { 
    return method;
}

std::string Client::getPath() const {
    return path;
}

std::string Client::getHTTPVersion() const {
    return httpVersion;
}

std::vector<std::pair<std::string, std::string> > Client::getHeaders() const {
    return headers;
}

std::string Client::getBody() const {
    return body;
}


std::string Client::getReqStr() const {
    return requestStr;
}

void Client::setReqStr(std::string s) {
    requestStr += s;
}


#include "../Includes/Socket.hpp"
#include <arpa/inet.h>
#include <iostream>

Socket::Socket(const std::vector<Server>& servers)
{
    
    epollfd = epoll_create(1);
    if (epollfd == -1) {
        throw std::runtime_error("Failed to create epoll instance");
    }
    for (std::vector<Server>::const_iterator it = servers.begin(); it != servers.end(); ++it) {
        const Server& server = *it;
        int sockfd = socket(AF_INET, SOCK_STREAM, 0);
        if (sockfd == -1) {
            throw std::runtime_error("Failed to create socket");
        }
        int opt = 1;
        if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) == -1) {
            close(sockfd);
            throw std::runtime_error("Failed to set socket options");
        }
        sockaddr_in addr;
        addr.sin_family = AF_INET;
        addr.sin_port = htons(server.getPort());
        if (inet_pton(AF_INET, server.getHost().c_str(), &addr.sin_addr) != 1) {
            close(sockfd);
            throw std::runtime_error("Invalid host or server name");
        }
        if (bind(sockfd, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) == -1) {
            close(sockfd);
            throw std::runtime_error("Failed to bind socket");
        }
        if (listen(sockfd, SOMAXCONN) == -1) {
            close(sockfd);
            throw std::runtime_error("Failed to listen on socket");
        }
        event.events = EPOLLIN;
        event.data.fd = sockfd;
        if (epoll_ctl(epollfd, EPOLL_CTL_ADD, sockfd, &event) == -1) {
            close(sockfd);
            throw std::runtime_error("Failed to add sockfd to epoll");
        }
        serverSockets.push_back(sockfd);
        //ClientServer = std::make_pair(i,sockfd);
    }
  
                    

}

Socket::~Socket()
{
    // for (size_t i = 0 ; i < serverSockets.size(); ++i) {
    //     close(serverSockets[i]);
    // }
    // close(epollfd);
}

// int ft_nonblocking(int fd)
// {
//     int flags = fcntl (fd, F_GETFL, 0);
//     if(flags == -1 )
//         return -1;
//     flags |= O_NONBLOCK;
//    if( fcntl (fd, F_SETFL, flags) == -1)
//         return -1;
//     return 0;
// }

void Socket::handleConnections()
{
    sockaddr_in clientAddr;
    socklen_t clientLen = sizeof(clientAddr);
    while (true)
    {

        int numEvents = epoll_wait(epollfd, events, maxEvents, -1);
        if (numEvents == -1) {
            throw std::runtime_error("Error in epoll_wait");
        }

        for (int i = 0; i < numEvents; ++i)
        {
            int sockfd = events[i].data.fd;

            if (std::find(serverSockets.begin(), serverSockets.end(), sockfd) != serverSockets.end())
            {

                int clientfd = accept(sockfd, reinterpret_cast<sockaddr*>(&clientAddr), &clientLen);
                Client c;
                c.setServFd(sockfd);
                c.setFd(clientfd);
                setMapClient(clientfd, c);
                if (clientfd == -1)
                    throw std::runtime_error("Failed to accept connection");
                // if(ft_nonblocking(clientfd) == -1)
                // {
                //     close(clientfd);
                //     throw std::runtime_error("Failed to add clientfd to fcntl");
                // }
                 
                event.events = EPOLLIN | EPOLLOUT;
                event.data.fd = clientfd;
                if (epoll_ctl(epollfd, EPOLL_CTL_ADD, clientfd, &event) == -1)
                {
                    close(clientfd);
                    throw std::runtime_error("Failed to add clientfd to epoll");
                }
            }
            else
            {
                if(events[i].data.fd & EPOLLIN && !mapClient[events[i].data.fd].getFlg())
                {
    
                    char buffer[1024] = {0};
                    ssize_t   bytesRead = recv(events[i].data.fd, buffer, 1023,0);
                
                    if (bytesRead == 0 || bytesRead == -1)
                    {
                        std::cerr << "Error reading from client\n";
                        close(sockfd);
                        epoll_ctl(epollfd, EPOLL_CTL_DEL, sockfd, static_cast<epoll_event*>(0));
                        mapClient.erase(sockfd);
                    }
                    std::string requestStr(buffer, bytesRead);
                    // Request req;
                    // req.parseRequest(requestStr);

                    mapClient[sockfd].set_request_client(requestStr);

                    //std::cout << sockfd<<": ***\n" <<mapClient[sockfd].getRequest().getBody() <<" ***\n";
                    //if(bytesRead == 0)
                    //mapClient[events[i].data.fd].setFlg(true); //yousraaaaaaaaa tkalfiii!!!!!
                }
                else if( events[i].data.fd  & EPOLLOUT && mapClient[events[i].data.fd].getFlg())
                {
                    write(events[i].data.fd, "hhhhhhhhh",9);
                    close(sockfd);
                }
            }
        }
    }
}

// void Socket::handleRequest(Client& client, const Request& request)
// {
//     Response response("200 OK", "");
//     if (request.getMethod() == "GET")
//         response = processGetRequest(request);
//     else if (request.getMethod() == "POST")
//         response = processPostRequest(request);
//     else if (request.getMethod() == "DELETE")
//         response = processDeleteRequest(request);
//     else
//         response = Response("405 Method Not Allowed", "Unsupported HTTP method");
//     std::string responseStr = response.toString();
//     send(client.getSocket(), responseStr.c_str(), responseStr.length(), 0);
// }

// Response Socket::processGetRequest(const Request& request) {
//     (void)request;
//     std::string body = "<html><body><h1>Hello, World!</h1></body></html>";
//     return Response("200 OK", body);
// }

// Response Socket::processPostRequest(const Request& request) {
//     (void)request;
//     std::string body = "Received POST request";
//     return Response("200 OK", body);
// }

// Response Socket::processDeleteRequest(const Request& request) {
//     (void)request;
//     std::string body = "Received DELETE request";
//     return Response("200 OK", body);
// }


Socket &Socket::operator=(Socket const &other)
{
   
        events[maxEvents] = other.events[maxEvents];
        epollfd = other.epollfd;
        // Client client = other.
        event = other.event;
        serverSockets = other.serverSockets;
        mapClient = other.mapClient;
    return *this;
}

Socket::Socket(Socket const &other)
{
    *this = other;
}

void    Socket::setMapClient(int fd, Client &c) {
    mapClient[fd] = c;
}

std::map<int, Client> Socket::getMapClient() const {
    return mapClient;
}

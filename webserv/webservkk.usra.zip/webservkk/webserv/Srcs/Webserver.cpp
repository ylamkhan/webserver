// #include "../Includes/webserver.hpp"


// Webserver::Webserver()
// {}

// Webserver::~Webserver()
// {}

// void Webserver::startWork(){}
// {
//     std::cout<<"starting working....\n";
//     for(int i = 0 ; i<servers.size(); i++)
//     {
//         boxServers = new Server(servers[i].port, servers[i].host);
//     }
    
// }

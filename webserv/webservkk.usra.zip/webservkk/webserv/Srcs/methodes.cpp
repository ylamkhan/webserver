#include "../Includes/Socket.hpp"
#include "../Includes/Client.hpp"
#include "../Includes/httpRequest.hpp"
#include "../Includes/httpRequest.hpp"



int ft_post(Client &client)
{

    Request eq;
    std::string body = eq.getBody();
    std::cout << body << "\n";
}
#include "iostream"

#define HHH 8
int main()
{
    HHH = 12;
    std::cout<<HHH<<"\n";
}